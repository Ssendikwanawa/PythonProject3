# File path to the dataset
file_path <- "D:\Ssendi\WK15\add_toGTable.xlsx" # Update the path to match your system


# Prev# Preview the first few rows of the dataset
head(timeliness_completeness_data)