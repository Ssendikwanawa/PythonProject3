from statsmodels.stats.multicomp import pairwise_tukeyhsd

print("Statsmodels is working!")
